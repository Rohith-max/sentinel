"""
Command-line interface for SCI
"""

import sys
from typing import List, Dict, Any
import click
from sentinelci import __version__
from sentinelci.config import get_config


@click.group(invoke_without_command=True)
@click.pass_context
@click.option("--scan", "root_scan", is_flag=True, help="Run scan via root flag")
@click.option("--watch", "root_watch", is_flag=True, help="Run watch via root flag")
@click.option("--fix", "root_fix", is_flag=True, help="Run auto-fix via root flag")
@click.option("--config", "root_config", is_flag=True, help="Run config wizard via root flag")
@click.option("--report", "root_report", is_flag=True, help="Run report via root flag")
@click.option("--version-info", "root_version", is_flag=True, help="Show extended version info")
@click.option("--path", "root_path", default=".", show_default=True, help="Path for scan/watch/fix")
@click.option("--target", "root_target", type=click.Path(), help="Override target for scan/watch/fix")
@click.option("--incident-file", default="findings.json", help="Input report file")
@click.option("--diff", is_flag=True, help="Use git diff file scope")
@click.option(
    "--severity",
    type=click.Choice(["low", "medium", "high", "critical"]),
    default="medium",
    show_default=True,
    help="Minimum severity level to report",
)
@click.option(
    "--format",
    "root_format",
    type=click.Choice(["terminal", "json", "markdown", "html"]),
    default="terminal",
    show_default=True,
    help="Output format",
)
@click.option("--output", "root_output", type=click.Path(), help="Output file for scan/report")
@click.option("--no-ai", is_flag=True, help="Disable AI analysis")
@click.option("--interval", default=2.0, type=click.FloatRange(min=0.5), show_default=True)
@click.option("--sync-github", is_flag=True, help="Fetch from GitHub remote before diff scans")
@click.option("--remote", default="origin", show_default=True, help="Git remote name")
@click.option("--branch", default=None, help="Git branch for remote diff comparison")
@click.option("--github-pat", default=None, help="GitHub PAT for authenticated remote fetch")
@click.option("--halt-on-critical", is_flag=True, help="Exit with failure on critical findings")
@click.option("--no-firmware", is_flag=True, help="Disable firmware CVE scanning")
@click.option("--no-urls", is_flag=True, help="Disable homograph URL detection")
@click.option("--dry-run", is_flag=True, help="Preview fix actions without writing files")
@click.option("--no-backup", is_flag=True, help="Disable .sci.bak backups during fix")
@click.version_option(version=__version__, prog_name="sci")
def main(
    ctx: click.Context,
    root_scan: bool,
    root_watch: bool,
    root_fix: bool,
    root_config: bool,
    root_report: bool,
    root_version: bool,
    root_path: str,
    root_target: str,
    incident_file: str,
    diff: bool,
    severity: str,
    root_format: str,
    root_output: str,
    no_ai: bool,
    interval: float,
    sync_github: bool,
    remote: str,
    branch: str,
    github_pat: str,
    halt_on_critical: bool,
    no_firmware: bool,
    no_urls: bool,
    dry_run: bool,
    no_backup: bool,
) -> None:
    """SCI - AI-powered security scanning for your code"""
    
    # Check for first-time installation
    cfg = get_config()
    is_first_run = not cfg.get_api_key() and not cfg.get_github_pat()
    
    # Show banner and onboarding on first run (unless running specific commands)
    if is_first_run and ctx.invoked_subcommand is None and not any([
        root_scan, root_watch, root_fix, root_config, root_report, root_version
    ]):
        from sentinelci.output.terminal import render_banner
        render_banner()
        
        click.echo("Welcome to SentinelCI! It looks like this is your first time.")
        click.echo("Let's get you set up with the interactive onboarding wizard.")
        click.echo()
        
        if click.confirm("Run setup wizard now?", default=True):
            # Import and run the modern onboarding
            try:
                import subprocess
                import sys
                result = subprocess.run([
                    sys.executable, "-m", "sentinelci.cli_new", "onboard"
                ], check=False)
                if result.returncode == 0:
                    click.echo("\nSetup complete! You can now use SentinelCI.")
                    click.echo("Try: sci scan")
                    return
            except Exception:
                pass
            
            # Fallback to basic setup
            click.echo("Setting up basic configuration...")
            click.echo("You can run 'sci github setup' later for GitHub integration.")
        else:
            click.echo("You can run setup later with: sci onboard")
            click.echo("Or use the modern CLI: python -m sentinelci.cli_new onboard")
    
    if ctx.invoked_subcommand is not None:
        return

    target_path = root_target or root_path

    if root_scan:
        ctx.invoke(
            scan,
            path=target_path,
            diff=diff,
            target=root_target,
            severity=severity,
            format=root_format if root_format != "html" else "terminal",
            output=root_output,
            no_ai=no_ai,
            watch=False,
            watch_interval=interval,
            sync_github=sync_github,
            remote=remote,
            branch=branch,
            github_pat=github_pat,
            halt_on_critical=halt_on_critical,
            no_firmware=no_firmware,
            no_urls=no_urls,
        )
        return

    if root_watch:
        ctx.invoke(
            watch,
            path=target_path,
            severity=severity,
            format=root_format if root_format != "html" else "terminal",
            output=root_output,
            no_ai=no_ai,
            interval=interval,
            sync_github=sync_github,
            remote=remote,
            branch=branch,
            github_pat=github_pat,
            halt_on_critical=halt_on_critical,
            no_firmware=no_firmware,
            no_urls=no_urls,
        )
        return

    if root_fix:
        ctx.invoke(
            fix,
            path=target_path,
            diff=diff,
            severity=severity,
            no_firmware=no_firmware,
            no_urls=no_urls,
            dry_run=dry_run,
            no_backup=no_backup,
        )
        return

    if root_config:
        ctx.invoke(config)
        return

    if root_report:
        ctx.invoke(
            report,
            incident_file=incident_file,
            format=root_format,
            output=root_output,
        )
        return

    if root_version:
        ctx.invoke(version)
        return

    click.echo(ctx.get_help())


@main.command()
@click.argument("path", default=".", required=False)
@click.option("--diff", is_flag=True, help="Scan git diff instead of directory")
@click.option("--target", type=click.Path(), help="Target directory or file to scan")
@click.option(
    "--severity",
    type=click.Choice(["low", "medium", "high", "critical"]),
    default="medium",
    help="Minimum severity level to report",
)
@click.option(
    "--format",
    type=click.Choice(["terminal", "json", "markdown"]),
    default="terminal",
    help="Output format",
)
@click.option(
    "--output", type=click.Path(), help="Output file path (for json/markdown formats)"
)
@click.option("--no-ai", is_flag=True, help="Disable AI analysis")
@click.option("--watch", is_flag=True, help="Watch mode - scan on each commit")
@click.option(
    "--watch-interval",
    type=click.FloatRange(min=0.5),
    default=2.0,
    show_default=True,
    help="Watch polling interval in seconds",
)
@click.option("--sync-github", is_flag=True, help="Fetch from GitHub remote before diff scans")
@click.option("--remote", default="origin", show_default=True, help="Git remote name")
@click.option("--branch", default=None, help="Git branch for remote diff comparison")
@click.option("--github-pat", default=None, help="GitHub PAT for authenticated remote fetch")
@click.option("--halt-on-critical", is_flag=True, help="Exit with error on critical findings")
@click.option("--no-firmware", is_flag=True, help="Disable firmware CVE scanning")
@click.option("--no-urls", is_flag=True, help="Disable homograph URL detection")
def scan(
    path: str,
    diff: bool,
    target: str,
    severity: str,
    format: str,
    output: str,
    no_ai: bool,
    watch: bool,
    watch_interval: float,
    sync_github: bool,
    remote: str,
    branch: str,
    github_pat: str,
    halt_on_critical: bool,
    no_firmware: bool,
    no_urls: bool,
) -> None:
    """Scan for security threats"""
    from sentinelci.scanner import run_scan

    try:
        exit_code = run_scan(
            path=target or path,
            use_diff=diff,
            severity=severity,
            output_format=format,
            output_file=output,
            use_ai=not no_ai,
            watch_mode=watch,
            watch_interval=watch_interval,
            sync_github=sync_github,
            remote=remote,
            branch=branch,
            github_pat=github_pat,
            halt_on_critical=halt_on_critical,
            enable_firmware=not no_firmware,
            enable_urls=not no_urls,
        )
        sys.exit(exit_code)
    except Exception as e:
        click.echo(f"FAILED: Scan failed: {str(e)}", err=True)
        sys.exit(1)


@main.command()
@click.argument("path", default=".", required=False)
@click.option(
    "--severity",
    type=click.Choice(["low", "medium", "high", "critical"]),
    default="medium",
    help="Minimum severity level to report",
)
@click.option(
    "--format",
    type=click.Choice(["terminal", "json", "markdown"]),
    default="terminal",
    help="Output format",
)
@click.option("--output", type=click.Path(), help="Output file path (for json/markdown formats)")
@click.option("--no-ai", is_flag=True, help="Disable AI analysis")
@click.option("--interval", type=click.FloatRange(min=0.5), default=2.0, show_default=True)
@click.option("--sync-github", is_flag=True, help="Fetch from GitHub remote before diff scans")
@click.option("--remote", default="origin", show_default=True, help="Git remote name")
@click.option("--branch", default=None, help="Git branch for remote diff comparison")
@click.option("--github-pat", default=None, help="GitHub PAT for authenticated remote fetch")
@click.option("--halt-on-critical", is_flag=True, help="Exit with error on critical findings")
@click.option("--no-firmware", is_flag=True, help="Disable firmware CVE scanning")
@click.option("--no-urls", is_flag=True, help="Disable homograph URL detection")
def watch(
    path: str,
    severity: str,
    format: str,
    output: str,
    no_ai: bool,
    interval: float,
    sync_github: bool,
    remote: str,
    branch: str,
    github_pat: str,
    halt_on_critical: bool,
    no_firmware: bool,
    no_urls: bool,
) -> None:
    """Watch files in real time and rescan on change"""
    from sentinelci.scanner import run_watch

    try:
        run_watch(
            path=path,
            severity=severity,
            output_format=format,
            output_file=output,
            use_ai=not no_ai,
            sync_github=sync_github,
            remote=remote,
            branch=branch,
            github_pat=github_pat,
            halt_on_critical=halt_on_critical,
            enable_firmware=not no_firmware,
            enable_urls=not no_urls,
            interval_seconds=interval,
        )
    except KeyboardInterrupt:
        click.echo("\n⏹️  Watch mode stopped")
        sys.exit(0)
    except Exception as e:
        click.echo(f"FAILED: Watch failed: {str(e)}", err=True)
        sys.exit(1)


@main.command()
@click.argument("path", default=".", required=False)
@click.option("--diff", is_flag=True, help="Fix based on git diff scope")
@click.option(
    "--severity",
    type=click.Choice(["low", "medium", "high", "critical"]),
    default="medium",
    help="Minimum severity level to include",
)
@click.option("--no-firmware", is_flag=True, help="Disable firmware CVE scanning")
@click.option("--no-urls", is_flag=True, help="Disable homograph URL detection")
@click.option("--dry-run", is_flag=True, help="Preview changes without writing files")
@click.option("--no-backup", is_flag=True, help="Do not create .sci.bak backup files")
def fix(
    path: str,
    diff: bool,
    severity: str,
    no_firmware: bool,
    no_urls: bool,
    dry_run: bool,
    no_backup: bool,
) -> None:
    """Auto-fix supported findings (secrets and homograph URLs)"""
    from sentinelci.fixer import run_fix

    try:
        summary = run_fix(
            path=path,
            use_diff=diff,
            severity=severity,
            enable_firmware=not no_firmware,
            enable_urls=not no_urls,
            dry_run=dry_run,
            backup=not no_backup,
        )
        click.echo(
            "\n".join(
                [
                    f"Total findings: {summary['total_findings']}",
                    f"Fixable: {summary['fixable']}",
                    f"Fixed: {summary['fixed']}",
                    f"Skipped: {summary['skipped']}",
                ]
            )
        )
        if summary["changes"]:
            click.echo("\nApplied changes:")
            for item in summary["changes"]:
                click.echo(f"- {item['action']} -> {item['file']}:{item['line']}")
    except Exception as e:
        click.echo(f"FAILED: Fix failed: {str(e)}", err=True)
        sys.exit(1)


@main.group()
def hook() -> None:
    """Manage git hooks for pre-commit scanning"""
    pass


@hook.command()
@click.option(
    "--blocking",
    is_flag=True,
    help="Fail commit on critical findings (default: warn only)",
)
def install(blocking: bool) -> None:
    """Install pre-commit git hook"""
    from sentinelci.hooks import install_hook

    try:
        install_hook(blocking=blocking)
        click.echo("SUCCESS: Git hook installed successfully")
    except Exception as e:
        click.echo(f"FAILED: Failed to install hook: {str(e)}", err=True)
        sys.exit(1)


@hook.command()
def remove() -> None:
    """Remove git hook"""
    from sentinelci.hooks import remove_hook

    try:
        remove_hook()
        click.echo("SUCCESS: Git hook removed")
    except Exception as e:
        click.echo(f"❌ Failed to remove hook: {str(e)}", err=True)
        sys.exit(1)


@main.command()
@click.argument("incident_file", required=False)
@click.option(
    "--format",
    type=click.Choice(["terminal", "json", "markdown", "html"]),
    default="terminal",
    help="Output format for the report",
)
@click.option("--output", type=click.Path(), help="Save report to file")
def report(incident_file: str, format: str, output: str) -> None:
    """Generate or convert security reports"""
    from sentinelci.output.report import render_report

    try:
        render_report(incident_file or "findings.json", format=format, output_file=output)
    except Exception as e:
        click.echo(f"❌ Report generation failed: {str(e)}", err=True)
        sys.exit(1)


@main.command()
@click.option("--ai-api-key", default=None, help="Set AI API key")
@click.option("--github-pat", default=None, help="Set GitHub PAT for sync")
@click.option("--nvd-api-key", default=None, help="Set NVD API key for CVE lookups")
@click.option("--clear-github-pat", is_flag=True, help="Remove stored GitHub PAT from config")
@click.option(
    "--severity",
    type=click.Choice(["low", "medium", "high", "critical"]),
    default=None,
    help="Set default minimum severity",
)
@click.option("--enable-firmware/--disable-firmware", default=None, help="Enable or disable firmware CVE scanning")
@click.option("--enable-urls/--disable-urls", default=None, help="Enable or disable homograph URL detection")
@click.option("--non-interactive", is_flag=True, help="Apply options and skip interactive onboarding wizard")
def config(
    ai_api_key: str,
    github_pat: str,
    nvd_api_key: str,
    clear_github_pat: bool,
    severity: str,
    enable_firmware: bool,
    enable_urls: bool,
    non_interactive: bool,
) -> None:
    """Configure SCI settings"""
    cfg = get_config()

    if any(value is not None for value in [ai_api_key, github_pat, nvd_api_key, severity, enable_firmware, enable_urls]) or clear_github_pat:
        cfg.configure_onboarding(
            ai_api_key=ai_api_key,
            github_pat=github_pat,
            nvd_api_key=nvd_api_key,
            clear_github_pat=clear_github_pat,
            severity=severity,
            enable_firmware=enable_firmware,
            enable_urls=enable_urls,
        )
        click.echo("✅ Configuration options saved")

    if non_interactive:
        click.echo("✅ Non-interactive onboarding complete")
        return

    cfg.setup_wizard()


@main.command()
def version() -> None:
    """Display version and environment information"""
    import platform
    from importlib.metadata import version as get_version

    click.echo(f"SCI {__version__}")
    click.echo(f"Python {platform.python_version()}")
    try:
        ai_sdk_version = get_version("groq")
        click.echo(f"AI SDK {ai_sdk_version}")
    except Exception:
        click.echo("AI SDK not installed")
    click.echo("AI Model: llama-3.3-70b-versatile")


@main.group()
def github() -> None:
    """GitHub integration and security analysis"""
    pass


@github.command()
def auth() -> None:
    """Check GitHub authentication status"""
    from sentinelci.github_auth import GitHubAuth

    try:
        auth = GitHubAuth()
        status = auth.check_auth_status()

        if status["authenticated"]:
            user = status["user"]
            orgs = status["organizations"]
            
            click.echo(f"✅ Authenticated as: [bold cyan]{user['login']}[/bold cyan]")
            click.echo(f"   Name: {user.get('name', 'N/A')}")
            click.echo(f"   Email: {user.get('email', 'N/A')}")
            click.echo(f"   Profile: {user.get('html_url', '')}")
            
            # Show token scopes
            try:
                scopes = auth.get_token_scopes()
                if scopes:
                    click.echo(f"\n🔑 Token Scopes:")
                    for scope in scopes:
                        click.echo(f"   • {scope}")
                    
                    # Check for required scopes
                    required = ['repo']
                    missing = [s for s in required if s not in scopes]
                    if missing:
                        click.echo(f"\n⚠️  Missing recommended scopes: {', '.join(missing)}")
                        click.echo("   Some features (like creating issues/PRs) may not work")
                else:
                    click.echo(f"\n⚠️  No scopes detected - token may have limited permissions")
            except Exception as e:
                click.echo(f"\n⚠️  Could not check token scopes: {str(e)}")
            
            if orgs:
                click.echo(f"\n📋 Organizations ({len(orgs)}):")
                for org in orgs[:10]:
                    click.echo(f"   • {org['login']}")
                if len(orgs) > 10:
                    click.echo(f"   ... and {len(orgs) - 10} more")
            else:
                click.echo("\n📋 No organizations")
        else:
            click.echo(f"❌ Not authenticated: {status['error']}")
            click.echo("\nRun 'sci github setup' to configure GitHub PAT")
            sys.exit(1)

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)


@github.command()
def setup() -> None:
    """Setup GitHub Personal Access Token"""
    from sentinelci.github_auth import GitHubAuth, GitHubAuthError

    try:
        auth = GitHubAuth()
        auth.prompt_and_store_pat()
        click.echo("\n✅ GitHub authentication configured successfully")
    except GitHubAuthError as e:
        click.echo(f"❌ Setup failed: {str(e)}", err=True)
        sys.exit(1)
    except KeyboardInterrupt:
        click.echo("\n❌ Setup cancelled")
        sys.exit(1)


@github.command()
def logout() -> None:
    """Remove GitHub Personal Access Token (logout)"""
    from sentinelci.config import get_config

    try:
        config = get_config()
        
        # Check if PAT exists
        if not config.get_github_pat():
            click.echo("INFO: No GitHub PAT configured - already logged out")
            return
        
        # Confirm logout
        if not click.confirm("Remove GitHub PAT and logout?", default=False):
            click.echo("Logout cancelled")
            return
        
        # Remove PAT from config
        config.remove("git", "github_pat")
        
        click.echo("SUCCESS: GitHub PAT removed successfully")
        click.echo("INFO: You are now logged out")
        click.echo("\nRun 'sci github setup' to login again")
        
    except Exception as e:
        click.echo(f"ERROR: {str(e)}", err=True)
        sys.exit(1)


@github.command()
def verify() -> None:
    """Verify autonomous agent execution results"""
    from sentinelci.core.verification import verify_latest_execution
    
    try:
        verify_latest_execution()
    except Exception as e:
        click.echo(f"ERROR: {str(e)}", err=True)
        sys.exit(1)


@github.command()
@click.option("--multi", is_flag=True, help="Select multiple repositories")
@click.option("--search", default=None, help="Filter repositories by name/description")
@click.option("--visibility", type=click.Choice(["public", "private"]), help="Filter by visibility")
@click.option("--language", default=None, help="Filter by programming language")
def repos(multi: bool, search: str, visibility: str, language: str) -> None:
    """List and select GitHub repositories"""
    from sentinelci.github_repos import GitHubRepoManager, GitHubAuthError

    try:
        manager = GitHubRepoManager()
        
        # Use lazy loading for faster initial display
        selected = manager.select_repositories_interactive_lazy(
            multi_select=multi,
            search=search,
            visibility=visibility,
            language=language
        )

        if selected:
            click.echo(f"\n✅ Selected {len(selected)} repository(ies):")
            for repo in selected:
                click.echo(f"   • {repo['full_name']}")
            
            # Show action menu for selected repositories
            _show_repo_action_menu(selected)
        else:
            click.echo("\n❌ No repositories selected")

    except GitHubAuthError as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        click.echo("\nRun 'sci github setup' to configure GitHub PAT")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)


def _show_repo_action_menu(repos: List[Dict[str, Any]]) -> None:
    """Show action menu for selected repositories"""
    try:
        import questionary
    except ImportError:
        click.echo("\n⚠️  Install questionary for interactive menu: pip install questionary")
        return

    actions = [
        "Analyze Security Configuration",
        "Run AI Security Analysis",
        "Autonomous Agent (Full Automation)",
        "Direct Fix (API - No Clone)",
        "Split Commits (Smart Chunking)",
        "Analyze & Fix Pipelines",
        "Full Analysis + Simulation",
        "Clone and Scan Code",
        "Export Repository Info",
        "Cancel",
    ]

    for repo in repos:
        click.echo(f"\n{'='*70}")
        click.echo(f"Repository: {repo['full_name']}")
        click.echo(f"{'='*70}\n")

        try:
            action = questionary.select(
                "What would you like to do?",
                choices=actions,
            ).ask()

            if not action or action == "Cancel":
                continue

            if action == "Analyze Security Configuration":
                _action_analyze_security(repo)
            elif action == "Run AI Security Analysis":
                _action_ai_analysis(repo)
            elif action == "Autonomous Agent (Full Automation)":
                _action_simulate_decisions(repo)
            elif action == "Direct Fix (API - No Clone)":
                _action_direct_fix(repo)
            elif action == "Split Commits (Smart Chunking)":
                _action_split_commits(repo)
            elif action == "Analyze & Fix Pipelines":
                _action_analyze_fix_pipelines(repo)
            elif action == "Full Analysis + Simulation":
                _action_full_analysis(repo)
            elif action == "Clone and Scan Code":
                _action_clone_and_scan(repo)
            elif action == "Export Repository Info":
                _action_export_info(repo)

        except KeyboardInterrupt:
            click.echo("\n❌ Cancelled")
            break


def _action_analyze_security(repo: Dict[str, Any]) -> None:
    """Analyze repository security configuration"""
    from sentinelci.github_security import GitHubSecurityAnalyzer
    from sentinelci.output.github_dashboard import render_github_dashboard

    try:
        analyzer = GitHubSecurityAnalyzer()
        click.echo(f"\n🔍 Analyzing security configuration...")
        
        analysis = analyzer.analyze_repository(repo['full_name'])
        risk_score = analyzer.calculate_risk_score(analysis)

        render_github_dashboard(analysis, risk_score)

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)


def _action_ai_analysis(repo: Dict[str, Any]) -> None:
    """Run AI security analysis"""
    from sentinelci.config import get_config
    from sentinelci.ai_analyzer import AISecurityAnalyzer
    from sentinelci.github_security import GitHubSecurityAnalyzer
    from sentinelci.output.ai_dashboard import render_ai_analysis
    import asyncio

    try:
        config = get_config()
        api_key = config.get_api_key()
        
        if not api_key:
            click.echo("❌ AI API key not configured. Run: sci --config")
            return

        click.echo(f"\n🤖 Running AI security analysis...")
        
        # Gather repository data
        github_analyzer = GitHubSecurityAnalyzer()
        analysis = github_analyzer.analyze_repository(repo['full_name'])
        
        # Prepare data for AI analysis
        metadata = {
            "name": repo['full_name'],
            "visibility": repo['visibility'],
            "language": repo.get('language', ''),
        }
        
        workflows = analysis.get('workflows', [])
        dependencies = []  # Would need to fetch from package files
        pipeline_data = {
            "ci_cd_files": analysis.get('ci_cd_files', {}),
            "failed_workflows": analysis.get('failed_workflows', []),
        }

        # Run AI analysis
        ai_analyzer = AISecurityAnalyzer(api_key)
        result = asyncio.run(
            ai_analyzer.analyze_repository(
                repo['full_name'],
                metadata,
                workflows,
                dependencies,
                pipeline_data,
            )
        )

        # Render results
        render_ai_analysis(result.to_dict())

        # Save to file
        import json
        output_file = f"{repo['name']}_ai_analysis.json"
        with open(output_file, 'w') as f:
            json.dump(result.to_dict(), f, indent=2)
        
        click.echo(f"\n💾 Analysis saved to: {output_file}")

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)


def _action_simulate_decisions(repo: Dict[str, Any]) -> None:
    """Run fully autonomous agent with complete automation"""
    from sentinelci.config import get_config
    from sentinelci.ai_analyzer import AISecurityAnalyzer
    from sentinelci.github_security import GitHubSecurityAnalyzer
    from sentinelci.core.autonomous_agent import AutonomousSecurityAgent
    import asyncio

    try:
        config = get_config()
        api_key = config.get_api_key()
        
        if not api_key:
            click.echo("ERROR: AI API key not configured. Run: sci --config")
            return

        click.echo(f"\nAutonomous Security Agent")
        click.echo(f"Repository: {repo['full_name']}\n")
        
        # Phase 1: Security Analysis
        click.echo("Phase 1: Security Analysis")
        
        github_analyzer = GitHubSecurityAnalyzer()
        analysis = github_analyzer.analyze_repository(repo['full_name'])
        
        metadata = {
            "name": repo['full_name'],
            "visibility": repo['visibility'],
            "language": repo.get('language', ''),
        }
        
        ai_analyzer = AISecurityAnalyzer(api_key)
        ai_result = asyncio.run(
            ai_analyzer.analyze_repository(
                repo['full_name'],
                metadata,
                analysis.get('workflows', []),
                [],
                {"ci_cd_files": analysis.get('ci_cd_files', {})},
            )
        )
        
        findings = [f.to_dict() for f in ai_result.findings]
        
        if not findings:
            click.echo("SUCCESS: No security issues found")
            return
        
        click.echo(f"Found {len(findings)} issue(s)\n")
        
        # Phase 2: Create autonomous plan
        click.echo("Phase 2: Planning Autonomous Actions")
        
        agent = AutonomousSecurityAgent()
        plan = asyncio.run(agent.analyze_and_plan(repo['full_name'], findings))
        
        # Phase 3: Display plan
        agent.display_plan(plan)
        
        # Phase 4: Ask for confirmation
        click.echo("WARNING: The agent will autonomously:")
        click.echo("  - Edit files to fix vulnerabilities")
        click.echo("  - Create commits with changes")
        click.echo("  - Push to new branch")
        click.echo("  - Open pull request")
        click.echo("  - Create tracking issues\n")
        
        if not click.confirm("Allow autonomous execution?", default=False):
            click.echo("\nExecution cancelled")
            
            # Save plan for review
            import json
            plan_file = f"{repo['name']}_autonomous_plan.json"
            with open(plan_file, 'w') as f:
                json.dump(plan.to_dict(), f, indent=2)
            click.echo(f"Plan saved to {plan_file}")
            return
        
        # Phase 5: Execute autonomously
        click.echo()
        results = asyncio.run(agent.execute_plan(plan, auto_approve=False))
        
        # Phase 6: Display results
        agent.display_results(results)
        
        # Save execution log
        import json
        log_file = f"{repo['name']}_execution_log.json"
        with open(log_file, 'w') as f:
            json.dump({
                "plan": plan.to_dict(),
                "results": results,
            }, f, indent=2)
        
        click.echo(f"Execution log saved to {log_file}")

    except Exception as e:
        click.echo(f"ERROR: {str(e)}", err=True)
        import traceback
        traceback.print_exc()


def _action_direct_fix(repo: Dict[str, Any]) -> None:
    """Fix vulnerabilities directly via GitHub API"""
    from sentinelci.config import get_config
    from sentinelci.core.github_direct_fixer import GitHubDirectFixer
    import requests

    try:
        config = get_config()
        github_token = config.get_github_pat()
        
        if not github_token:
            click.echo("❌ GitHub PAT not configured. Run: sci github setup")
            return
        
        click.echo(f"\n🔍 Scanning repository: {repo['full_name']}")
        
        owner, repo_name = repo['full_name'].split("/")
        
        # Initialize fixer
        fixer = GitHubDirectFixer(github_token)
        
        # Get repository default branch
        headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github.v3+json",
        }
        
        repo_url = f"https://api.github.com/repos/{owner}/{repo_name}"
        repo_response = requests.get(repo_url, headers=headers, timeout=30)
        
        if repo_response.status_code != 200:
            click.echo(f"❌ Failed to access repository: {repo_response.status_code}")
            return
        
        repo_data = repo_response.json()
        default_branch = repo_data.get("default_branch", "main")
        
        # Check if repository is empty
        if repo_data.get("size", 0) == 0:
            click.echo("❌ Repository is empty - no files to scan")
            return
        
        # Get repository files to scan
        click.echo(f"📥 Fetching repository files from branch '{default_branch}'...")
        
        # Get repository tree
        tree_url = f"https://api.github.com/repos/{owner}/{repo_name}/git/trees/{default_branch}?recursive=1"
        response = requests.get(tree_url, headers=headers, timeout=30)
        
        if response.status_code == 409:
            click.echo(f"❌ Repository is empty or has no commits")
            return
        elif response.status_code == 404:
            click.echo(f"❌ Branch '{default_branch}' not found")
            return
        elif response.status_code != 200:
            click.echo(f"❌ Failed to fetch repository: {response.status_code} - {response.text}")
            return
        
        tree_data = response.json()
        files = [item for item in tree_data.get("tree", []) if item["type"] == "blob"]
        
        if not files:
            click.echo("❌ No files found in repository")
            return
        
        # Filter scannable files
        scannable_extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".yml", ".yaml", ".json", ".env"}
        scannable_files = [
            f for f in files 
            if any(f["path"].endswith(ext) for ext in scannable_extensions)
            and not any(skip in f["path"] for skip in ["node_modules", ".git", "__pycache__", ".venv"])
        ]
        
        if not scannable_files:
            click.echo("❌ No scannable files found")
            return
        
        click.echo(f"📄 Found {len(scannable_files)} files to scan")
        
        # Scan files for vulnerabilities
        click.echo(f"\n🔍 Scanning for vulnerabilities...")
        all_findings = []
        
        for file_info in scannable_files[:50]:  # Limit to 50 files for API rate limits
            file_path = file_info["path"]
            
            # Get file content
            github_file = fixer.get_file_content(owner, repo_name, file_path, default_branch)
            if not github_file:
                continue
            
            # Scan for secrets
            secrets = fixer.extract_secrets_from_content(github_file.content, file_path)
            
            for secret in secrets:
                all_findings.append({
                    "type": "Hardcoded Secret",
                    "severity": "HIGH",
                    "file": file_path,
                    "line_number": secret["line"],
                    "description": f"Hardcoded {secret['type']} found",
                })
            
            # Check workflows for issues
            if file_path.endswith((".yml", ".yaml")) and ".github/workflows" in file_path:
                content = github_file.content
                
                # Check for write-all permissions
                if "write-all" in content:
                    all_findings.append({
                        "type": "Excessive Permissions",
                        "severity": "HIGH",
                        "file": file_path,
                        "line_number": 0,
                        "description": "Workflow has write-all permissions",
                    })
                
                # Check for unpinned actions
                if "@main" in content or "@master" in content:
                    all_findings.append({
                        "type": "Unpinned Action",
                        "severity": "MEDIUM",
                        "file": file_path,
                        "line_number": 0,
                        "description": "Action pinned to branch instead of commit SHA",
                    })
        
        if not all_findings:
            click.echo("\n✅ No vulnerabilities found!")
            return
        
        click.echo(f"\n⚠️  Found {len(all_findings)} issue(s)")
        
        # Show summary
        severity_counts = {}
        for finding in all_findings:
            sev = finding.get("severity", "UNKNOWN")
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            if sev in severity_counts:
                click.echo(f"  {sev}: {severity_counts[sev]}")
        
        # Confirm
        if not click.confirm("\n🔧 Apply fixes directly to GitHub?", default=True):
            click.echo("❌ Cancelled")
            return
        
        # Fix
        click.echo(f"\n🔧 Applying fixes via GitHub API...")
        result = fixer.analyze_and_fix_repository(
            owner=owner,
            repo=repo_name,
            findings=all_findings,
            base_branch=default_branch,
            auto_commit=True
        )
        
        if result["success"]:
            click.echo(f"\n✅ Fixed {len(result['fixed_files'])} file(s)")
            click.echo(f"   Branch: {result['branch']}")
            
            if result.get("pr_url"):
                click.echo(f"   PR: {result['pr_url']}")
            
            if result.get("env_vars", 0) > 0:
                click.echo(f"\n⚠️  {result['env_vars']} environment variable(s) extracted")
                click.echo(f"   Add these to GitHub Secrets")
        else:
            click.echo(f"\n❌ Fix failed: {result.get('error', 'Unknown error')}")

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        import traceback
        traceback.print_exc()


def _action_analyze_fix_pipelines(repo: Dict[str, Any]) -> None:
    """Analyze existing pipelines and autonomously fix errors"""
    from sentinelci.config import get_config
    from sentinelci.core.pipeline_fixer import PipelineErrorDetector, PipelineFixer
    import requests
    import yaml

    try:
        config = get_config()
        github_token = config.get_github_pat()
        
        if not github_token:
            click.echo("❌ GitHub PAT not configured. Run: sci github setup")
            return
        
        click.echo(f"\n🔍 Analyzing pipelines in: {repo['full_name']}")
        
        owner, repo_name = repo['full_name'].split("/")
        
        # Get workflows
        headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github.v3+json",
        }
        
        workflows_url = f"https://api.github.com/repos/{owner}/{repo_name}/actions/workflows"
        response = requests.get(workflows_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            click.echo(f"❌ Failed to fetch workflows: {response.status_code}")
            return
        
        workflows = response.json().get("workflows", [])
        
        if not workflows:
            click.echo("⚠️  No workflows found in repository")
            return
        
        click.echo(f"\n📋 Found {len(workflows)} workflow(s):")
        for wf in workflows:
            state_icon = "✅" if wf["state"] == "active" else "⚠️"
            click.echo(f"   {state_icon} {wf['name']} ({wf['path']})")
        
        # Analyze each workflow
        detector = PipelineErrorDetector()
        all_issues = []
        workflow_contents = {}
        
        for workflow in workflows:
            workflow_path = workflow["path"]
            click.echo(f"\n🔍 Analyzing: {workflow_path}")
            
            # Get workflow content
            content_url = f"https://api.github.com/repos/{owner}/{repo_name}/contents/{workflow_path}"
            content_response = requests.get(content_url, headers=headers, timeout=30)
            
            if content_response.status_code != 200:
                click.echo(f"   ❌ Failed to fetch content")
                continue
            
            import base64
            content = base64.b64decode(content_response.json()["content"]).decode("utf-8")
            workflow_contents[workflow_path] = content
            
            # Parse YAML
            try:
                workflow_data = yaml.safe_load(content)
            except yaml.YAMLError as e:
                click.echo(f"   ❌ YAML parsing error: {str(e)}")
                all_issues.append({
                    "workflow": workflow_path,
                    "type": "YAML Syntax Error",
                    "severity": "CRITICAL",
                    "description": str(e),
                    "fixable": False
                })
                continue
            
            # Detect issues
            issues = detector.analyze_workflow(workflow_path, content)
            
            if issues:
                click.echo(f"   ⚠️  Found {len(issues)} issue(s)")
                for issue in issues:
                    severity_color = {
                        "CRITICAL": "red",
                        "HIGH": "yellow",
                        "MEDIUM": "blue",
                        "LOW": "white"
                    }.get(issue.severity, "white")
                    
                    click.echo(f"      • [{issue.severity}] {issue.category.value}: {issue.description}")
                    all_issues.append({
                        "workflow": workflow_path,
                        "type": issue.category.value,
                        "severity": issue.severity,
                        "description": issue.description,
                        "line": issue.line_number,
                        "fixable": issue.auto_fixable,
                        "fix_suggestion": issue.recommended_fix,
                        "current_value": issue.current_value
                    })
            else:
                click.echo(f"   ✅ No issues found")
        
        if not all_issues:
            click.echo("\n✅ All pipelines are healthy!")
            return
        
        # Show summary
        click.echo(f"\n📊 Summary:")
        severity_counts = {}
        fixable_count = 0
        
        for issue in all_issues:
            sev = issue["severity"]
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
            if issue["fixable"]:
                fixable_count += 1
        
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            if sev in severity_counts:
                click.echo(f"   {sev}: {severity_counts[sev]}")
        
        click.echo(f"\n🔧 Auto-fixable: {fixable_count}/{len(all_issues)}")
        
        # Offer to fix
        if fixable_count == 0:
            click.echo("\n⚠️  No auto-fixable issues found")
            click.echo("💡 Manual review required for these issues")
            return
        
        if not click.confirm(f"\n🔧 Automatically fix {fixable_count} issue(s)?", default=True):
            click.echo("❌ Cancelled")
            return
        
        # Fix issues
        click.echo("\n🔧 Applying fixes...")
        fixer = PipelineFixer()
        fixed_workflows = {}
        
        for workflow_path, content in workflow_contents.items():
            workflow_issues = [i for i in all_issues if i["workflow"] == workflow_path and i["fixable"]]
            
            if not workflow_issues:
                continue
            
            click.echo(f"\n   Fixing: {workflow_path}")
            
            try:
                # Re-analyze to get PipelineError objects
                errors = detector.analyze_workflow(workflow_path, content)
                fixable_errors = [e for e in errors if e.auto_fixable]
                
                if not fixable_errors:
                    continue
                
                # Apply fixes one by one
                fixed_content = content
                fixes_applied = 0
                
                for error in fixable_errors:
                    # Apply fix directly based on error category
                    if error.category.value == "workflow_permissions":
                        fixed_content, success = fixer.fix_permissions(fixed_content, error)
                        if success:
                            fixes_applied += 1
                    elif error.category.value == "code_injection":
                        fixed_content, success = fixer.fix_code_injection(fixed_content, error)
                        if success:
                            fixes_applied += 1
                
                if fixes_applied > 0:
                    fixed_workflows[workflow_path] = fixed_content
                    click.echo(f"   ✅ Fixed {fixes_applied} issue(s)")
                else:
                    click.echo(f"   ⚠️  No fixes could be applied")
                
            except Exception as e:
                click.echo(f"   ❌ Fix failed: {str(e)}")
        
        if not fixed_workflows:
            click.echo("\n❌ No workflows were fixed")
            return
        
        # Create branch and commit fixes
        click.echo(f"\n📤 Creating branch and committing fixes...")
        
        # Get default branch
        repo_url = f"https://api.github.com/repos/{owner}/{repo_name}"
        repo_response = requests.get(repo_url, headers=headers, timeout=30)
        default_branch = repo_response.json().get("default_branch", "main")
        
        # Get latest commit SHA
        ref_url = f"https://api.github.com/repos/{owner}/{repo_name}/git/refs/heads/{default_branch}"
        ref_response = requests.get(ref_url, headers=headers, timeout=30)
        base_sha = ref_response.json()["object"]["sha"]
        
        # Create new branch
        branch_name = f"fix/pipeline-issues-{base_sha[:7]}"
        create_ref_url = f"https://api.github.com/repos/{owner}/{repo_name}/git/refs"
        create_ref_data = {
            "ref": f"refs/heads/{branch_name}",
            "sha": base_sha
        }
        
        branch_response = requests.post(create_ref_url, headers=headers, json=create_ref_data, timeout=30)
        
        if branch_response.status_code not in [201, 422]:  # 422 = already exists
            click.echo(f"❌ Failed to create branch: {branch_response.status_code}")
            return
        
        click.echo(f"   ✅ Created branch: {branch_name}")
        
        # Commit each fixed workflow
        for workflow_path, fixed_content in fixed_workflows.items():
            update_url = f"https://api.github.com/repos/{owner}/{repo_name}/contents/{workflow_path}"
            
            # Get current file SHA
            file_response = requests.get(update_url, headers=headers, timeout=30)
            file_sha = file_response.json()["sha"]
            
            # Update file
            import base64
            update_data = {
                "message": f"fix: Resolve pipeline issues in {workflow_path}",
                "content": base64.b64encode(fixed_content.encode()).decode(),
                "sha": file_sha,
                "branch": branch_name
            }
            
            update_response = requests.put(update_url, headers=headers, json=update_data, timeout=30)
            
            if update_response.status_code == 200:
                click.echo(f"   ✅ Committed: {workflow_path}")
            else:
                click.echo(f"   ❌ Failed to commit: {workflow_path}")
        
        # Create pull request
        if click.confirm("\n📝 Create pull request?", default=True):
            pr_url = f"https://api.github.com/repos/{owner}/{repo_name}/pulls"
            pr_data = {
                "title": f"🔧 Fix {fixable_count} pipeline issue(s)",
                "body": f"## Pipeline Fixes\n\nAutomatically fixed {fixable_count} issue(s) in CI/CD pipelines:\n\n" + 
                        "\n".join([f"- [{i['severity']}] {i['type']}: {i['description']}" for i in all_issues if i['fixable']]),
                "head": branch_name,
                "base": default_branch
            }
            
            pr_response = requests.post(pr_url, headers=headers, json=pr_data, timeout=30)
            
            if pr_response.status_code == 201:
                pr_url_link = pr_response.json()["html_url"]
                click.echo(f"\n✅ Pull request created: {pr_url_link}")
            else:
                click.echo(f"\n❌ Failed to create PR: {pr_response.status_code}")
        
        click.echo(f"\n✅ Pipeline fixes complete!")

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        import traceback
        traceback.print_exc()


def _action_split_commits(repo: Dict[str, Any]) -> None:
    """Clone repository and split large commits intelligently"""
    from sentinelci.core.commit_splitter import CommitSplitter
    from sentinelci.core.pipeline_optimizer import PipelineOptimizer
    import tempfile
    import shutil
    import subprocess
    from pathlib import Path
    import questionary

    try:
        click.echo(f"\n📦 Cloning repository: {repo['full_name']}")
        
        # Create temporary directory
        temp_dir = tempfile.mkdtemp(prefix="sci_split_")
        repo_path = Path(temp_dir) / repo['name']
        
        try:
            # Clone repository
            clone_url = repo['clone_url']
            result = subprocess.run(
                ["git", "clone", clone_url, str(repo_path)],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=300
            )
            
            if result.returncode != 0:
                click.echo(f"❌ Failed to clone: {result.stderr}")
                return
            
            click.echo(f"✅ Repository cloned")
            
            # Get recent commits
            click.echo("\n📜 Fetching recent commits...")
            log_result = subprocess.run(
                ["git", "log", "--oneline", "-20", "--no-decorate"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )
            
            if log_result.returncode != 0:
                click.echo(f"❌ Failed to get commits: {log_result.stderr}")
                return
            
            # Parse commits
            commits = []
            for line in log_result.stdout.strip().split("\n"):
                if not line.strip():
                    continue
                parts = line.split(" ", 1)
                if len(parts) == 2:
                    commit_hash, message = parts
                    
                    # Get commit stats
                    stat_result = subprocess.run(
                        ["git", "show", "--stat", "--format=", commit_hash],
                        cwd=repo_path,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace"
                    )
                    
                    # Count files changed
                    files_changed = len([l for l in stat_result.stdout.split("\n") if "|" in l])
                    
                    commits.append({
                        "hash": commit_hash,
                        "message": message,
                        "files_changed": files_changed,
                        "display": f"{commit_hash} - {message} ({files_changed} files)"
                    })
            
            if not commits:
                click.echo("❌ No commits found")
                return
            
            # Let user select commit to split
            click.echo(f"\n📋 Found {len(commits)} recent commits")
            
            commit_choices = [c["display"] for c in commits]
            commit_choices.append("Cancel")
            
            selected = questionary.select(
                "Select a commit to split:",
                choices=commit_choices
            ).ask()
            
            if not selected or selected == "Cancel":
                click.echo("❌ Cancelled")
                return
            
            # Find selected commit
            selected_commit = None
            for commit in commits:
                if commit["display"] == selected:
                    selected_commit = commit
                    break
            
            if not selected_commit:
                click.echo("❌ Commit not found")
                return
            
            click.echo(f"\n🔍 Analyzing commit: {selected_commit['hash']}")
            
            # Get commit diff
            diff_result = subprocess.run(
                ["git", "show", "--stat", selected_commit["hash"]],
                cwd=repo_path,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )
            
            click.echo(f"\n� Commit Details:")
            click.echo(f"   Hash: {selected_commit['hash']}")
            click.echo(f"   Message: {selected_commit['message']}")
            click.echo(f"   Files: {selected_commit['files_changed']}")
            
            # Reset to parent commit to "undo" the selected commit
            click.echo(f"\n🔄 Resetting to parent commit...")
            reset_result = subprocess.run(
                ["git", "reset", "--soft", f"{selected_commit['hash']}^"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )
            
            if reset_result.returncode != 0:
                click.echo(f"❌ Failed to reset: {reset_result.stderr}")
                return
            
            # Initialize splitter
            splitter = CommitSplitter(str(repo_path))
            
            # Analyze staged changes
            click.echo("\n🔍 Analyzing changes...")
            changes = splitter.analyze_staged_changes()
            
            if not changes:
                click.echo("❌ No files to split")
                return
            
            # Categorize changes
            groups = splitter.categorize_changes(changes)
            
            click.echo(f"\n📊 Analysis Results:")
            click.echo(f"   Files: {len(changes)}")
            
            total_additions = sum(c.additions for c in changes)
            total_deletions = sum(c.deletions for c in changes)
            click.echo(f"   Additions: +{total_additions}")
            click.echo(f"   Deletions: -{total_deletions}")
            
            # Show suggested splits
            click.echo(f"\n💡 Suggested commit groups:")
            for i, group in enumerate(groups, 1):
                click.echo(f"\n   Group {i}: {group.name}")
                click.echo(f"   Files: {len(group.files)}")
                if group.description:
                    click.echo(f"   Description: {group.description}")
            
            # Confirm
            if not click.confirm(f"\n🔧 Split into {len(groups)} commits?", default=True):
                click.echo("❌ Cancelled")
                # Restore original commit
                subprocess.run(
                    ["git", "reset", "--hard", selected_commit["hash"]], 
                    cwd=repo_path,
                    encoding="utf-8",
                    errors="replace"
                )
                return
            
            # Perform split
            click.echo(f"\n🔧 Creating commits...")
            result = splitter.split_current_commit(dry_run=False)
            
            if result["success"]:
                click.echo(f"\n✅ Created {len(result['commits'])} commit(s):")
                
                # Collect commit info for pipeline optimization
                commit_analyses = []
                
                for commit_sha in result["commits"]:
                    # Get commit message
                    msg_result = subprocess.run(
                        ["git", "log", "-1", "--format=%s", commit_sha],
                        cwd=repo_path,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace"
                    )
                    message = msg_result.stdout.strip()
                    
                    # Get changed files in this commit
                    files_result = subprocess.run(
                        ["git", "diff-tree", "--no-commit-id", "--name-only", "-r", commit_sha],
                        cwd=repo_path,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace"
                    )
                    changed_files = files_result.stdout.strip().split("\n")
                    
                    click.echo(f"   • {commit_sha[:8]}: {message}")
                    
                    # Analyze for pipeline optimization
                    optimizer = PipelineOptimizer()
                    analysis = optimizer.analyze_commit(message, changed_files)
                    commit_analyses.append(analysis)
                
                # Generate pipeline optimization
                click.echo("\n🚀 Analyzing pipeline optimization opportunities...")
                optimizer = PipelineOptimizer()
                optimization = optimizer.optimize_pipeline(commit_analyses)
                
                # Show optimization report
                report = optimizer.generate_optimization_report(optimization)
                click.echo(f"\n{report}")
                
                # Offer to generate optimized workflow
                if click.confirm("\n📝 Generate optimized GitHub Actions workflow?", default=False):
                    workflow_content = optimizer.generate_optimized_workflow(optimization)
                    workflow_path = repo_path / ".github" / "workflows" / "optimized-ci.yml"
                    workflow_path.parent.mkdir(parents=True, exist_ok=True)
                    workflow_path.write_text(workflow_content)
                    
                    click.echo(f"✅ Workflow saved to: .github/workflows/optimized-ci.yml")
                    
                    # Stage and commit the workflow
                    subprocess.run(
                        ["git", "add", ".github/workflows/optimized-ci.yml"],
                        cwd=repo_path,
                        encoding="utf-8",
                        errors="replace"
                    )
                    subprocess.run(
                        ["git", "commit", "-m", "ci: Add optimized pipeline workflow"],
                        cwd=repo_path,
                        encoding="utf-8",
                        errors="replace"
                    )
                    click.echo("✅ Workflow committed")
                
                # Ask to push
                if click.confirm("\n📤 Force push commits to remote?", default=False):
                    click.echo("⚠️  This will rewrite history!")
                    if click.confirm("Are you sure?", default=False):
                        push_result = subprocess.run(
                            ["git", "push", "--force"],
                            cwd=repo_path,
                            capture_output=True,
                            text=True,
                            encoding="utf-8",
                            errors="replace"
                        )
                        
                        if push_result.returncode == 0:
                            click.echo("✅ Pushed successfully")
                        else:
                            click.echo(f"❌ Push failed: {push_result.stderr}")
                else:
                    click.echo("💡 Commits created locally but not pushed")
            else:
                click.echo(f"\n❌ Split failed: {result.get('error', 'Unknown error')}")
        
        finally:
            # Cleanup
            if click.confirm("\n🗑️  Delete cloned repository?", default=True):
                shutil.rmtree(temp_dir, ignore_errors=True)
                click.echo("✅ Cleaned up")
            else:
                click.echo(f"📁 Repository kept at: {repo_path}")

    except subprocess.TimeoutExpired:
        click.echo("❌ Operation timed out")
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        import traceback
        traceback.print_exc()


def _action_full_analysis(repo: Dict[str, Any]) -> None:
    """Run full analysis with simulation"""
    from sentinelci.config import get_config
    from sentinelci.ai_analyzer import AISecurityAnalyzer
    from sentinelci.autonomous_engine import AutonomousEngine
    from sentinelci.github_security import GitHubSecurityAnalyzer
    from sentinelci.output.ai_dashboard import render_combined_report
    import asyncio
    import json

    try:
        config = get_config()
        api_key = config.get_api_key()
        
        if not api_key:
            click.echo("❌ AI API key not configured. Run: sci --config")
            return

        click.echo(f"\n🚀 Running full security analysis...")
        
        # Gather repository data
        github_analyzer = GitHubSecurityAnalyzer()
        analysis = github_analyzer.analyze_repository(repo['full_name'])
        
        metadata = {
            "name": repo['full_name'],
            "visibility": repo['visibility'],
            "language": repo.get('language', ''),
        }
        
        workflows = analysis.get('workflows', [])
        dependencies = []
        pipeline_data = {
            "ci_cd_files": analysis.get('ci_cd_files', {}),
            "failed_workflows": analysis.get('failed_workflows', []),
        }

        # Run AI analysis
        ai_analyzer = AISecurityAnalyzer(api_key)
        ai_result = asyncio.run(
            ai_analyzer.analyze_repository(
                repo['full_name'],
                metadata,
                workflows,
                dependencies,
                pipeline_data,
            )
        )

        # Simulate decisions
        engine = AutonomousEngine()
        simulation = engine.simulate(
            repo['full_name'],
            [f.to_dict() for f in ai_result.findings],
        )

        # Render combined report
        render_combined_report(ai_result.to_dict(), simulation.to_dict())

        # Save to files
        analysis_file = f"{repo['name']}_full_analysis.json"
        with open(analysis_file, 'w') as f:
            json.dump({
                "ai_analysis": ai_result.to_dict(),
                "autonomous_decisions": simulation.to_dict(),
            }, f, indent=2)
        
        click.echo(f"\n💾 Full analysis saved to: {analysis_file}")

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)


def _action_clone_and_scan(repo: Dict[str, Any]) -> None:
    """Clone repository and scan code"""
    import subprocess
    import tempfile
    import shutil
    from pathlib import Path
    import os

    try:
        click.echo(f"\n📥 Cloning repository...")
        
        # Create temp directory
        temp_dir = tempfile.mkdtemp()
        repo_path = Path(temp_dir) / repo['name']
        
        click.echo(f"Temp directory: {temp_dir}")
        click.echo(f"Clone URL: {repo['clone_url']}")
        
        # Clone repository with explicit config to ensure working tree
        result = subprocess.run(
            [
                "git", "clone",
                "--config", "core.bare=false",
                "--config", "core.worktree=.",
                repo['clone_url'],
                str(repo_path)
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )
        
        if result.returncode != 0:
            click.echo(f"❌ Clone failed: {result.stderr}")
            
            # Check if repository is empty
            if "does not have any commits yet" in result.stderr or "empty repository" in result.stderr.lower():
                click.echo("⚠️  Repository appears to be empty (no commits)")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            
            shutil.rmtree(temp_dir, ignore_errors=True)
            return
        
        click.echo(f"✅ Cloned to: {repo_path}")
        
        # Verify clone worked - check if files exist
        if not repo_path.exists():
            click.echo(f"❌ Repository path doesn't exist: {repo_path}")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return
        
        # Check if .git exists
        git_dir = repo_path / ".git"
        if not git_dir.exists():
            click.echo(f"❌ .git directory not found - clone may have failed")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return
        
        # List files to verify
        files = [f for f in repo_path.iterdir() if f.name != '.git']
        all_items = list(repo_path.iterdir())
        
        click.echo(f"📁 Found {len(all_items)} items in repository:")
        for f in all_items[:10]:  # Show first 10 items
            click.echo(f"  - {f.name}")
        if len(all_items) > 10:
            click.echo(f"  ... and {len(all_items) - 10} more")
        
        # Check if repository is empty (only .git)
        if len(files) == 0:
            click.echo("\n⚠️  Repository appears to be empty (no files besides .git)")
            
            # Check if there are any commits
            check_commits = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
            )
            
            if check_commits.returncode != 0:
                click.echo("⚠️  No commits found in repository - nothing to scan")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            
            # Try to list branches
            list_branches = subprocess.run(
                ["git", "branch", "-a"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
            )
            
            click.echo(f"Branches: {list_branches.stdout}")
            
            # Try to reset to HEAD
            click.echo("Attempting to restore working tree...")
            reset_result = subprocess.run(
                ["git", "reset", "--hard", "HEAD"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
            )
            
            if reset_result.returncode != 0:
                click.echo(f"❌ Reset failed: {reset_result.stderr}")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            
            # Re-check files
            files = [f for f in repo_path.iterdir() if f.name != '.git']
            click.echo(f"📁 After reset: {len(files)} files (excluding .git)")
            
            if len(files) == 0:
                click.echo("❌ Still no files - repository may be truly empty")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
        
        click.echo(f"\n🔍 Scanning code...")
        
        # Run scan
        from sentinelci.scanner import run_scan
        exit_code = run_scan(
            path=str(repo_path),
            use_diff=False,
            severity="medium",
            output_format="terminal",
            output_file=None,
            use_ai=True,
            watch_mode=False,
            enable_firmware=True,
            enable_urls=True,
        )
        
        # Cleanup
        click.echo(f"\n🧹 Cleaning up temporary directory...")
        shutil.rmtree(temp_dir, ignore_errors=True)
        
        if exit_code == 0:
            click.echo("\n✅ Scan completed successfully")
        else:
            click.echo(f"\n⚠️  Scan completed with exit code: {exit_code}")

    except subprocess.TimeoutExpired:
        click.echo(f"❌ Clone timed out after 300 seconds")
        if 'temp_dir' in locals():
            shutil.rmtree(temp_dir, ignore_errors=True)
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        import traceback
        traceback.print_exc()
        if 'temp_dir' in locals():
            shutil.rmtree(temp_dir, ignore_errors=True)


def _action_export_info(repo: Dict[str, Any]) -> None:
    """Export repository information"""
    import json

    try:
        output_file = f"{repo['name']}_info.json"
        
        with open(output_file, 'w') as f:
            json.dump(repo, f, indent=2)
        
        click.echo(f"\n💾 Repository info exported to: {output_file}")
        click.echo(f"\nRepository: {repo['full_name']}")
        click.echo(f"Visibility: {repo['visibility']}")
        click.echo(f"Language: {repo.get('language', 'N/A')}")
        click.echo(f"Stars: {repo.get('stars', 0)}")
        click.echo(f"Open PRs: {repo.get('open_prs', 0)}")

    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)


@github.command()
@click.argument("repository")
@click.option("--output", type=click.Path(), help="Save analysis to JSON file")
def analyze(repository: str, output: str) -> None:
    """Analyze GitHub repository security configuration"""
    from sentinelci.github_security import GitHubSecurityAnalyzer, GitHubAuthError
    from sentinelci.output.github_dashboard import render_github_dashboard
    import json

    try:
        analyzer = GitHubSecurityAnalyzer()
        
        click.echo(f"🔍 Analyzing repository: {repository}\n")
        
        analysis = analyzer.analyze_repository(repository)
        risk_score = analyzer.calculate_risk_score(analysis)

        render_github_dashboard(analysis, risk_score)

        if output:
            output_data = {
                "analysis": analysis,
                "risk_score": risk_score,
            }
            
            with open(output, "w") as f:
                json.dump(output_data, f, indent=2)
            
            click.echo(f"\n💾 Analysis saved to: {output}")

    except GitHubAuthError as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        click.echo("\nRun 'sci github setup' to configure GitHub PAT")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)


@github.command()
@click.argument("repository")
@click.option("--branch", default="main", help="Base branch to create PR against")
@click.option("--dry-run", is_flag=True, help="Preview changes without committing")
@click.option("--severity", default="medium", help="Minimum severity to fix")
def direct_fix(repository: str, branch: str, dry_run: bool, severity: str) -> None:
    """Fix vulnerabilities directly in GitHub repository via API"""
    from sentinelci.config import get_config
    from sentinelci.github_security import GitHubSecurityAnalyzer, GitHubAuthError
    from sentinelci.scanner import collect_findings
    from sentinelci.core.github_direct_fixer import fix_github_repository_direct
    import tempfile
    import os
    import subprocess

    try:
        config = get_config()
        github_token = config.get_github_pat()
        
        if not github_token:
            click.echo("❌ GitHub PAT not configured. Run: sci github setup")
            sys.exit(1)
        
        click.echo(f"🔍 Scanning repository: {repository}\n")
        
        # Parse owner/repo
        try:
            owner, repo = repository.split("/")
        except ValueError:
            click.echo("❌ Invalid repository format. Use: owner/repo")
            sys.exit(1)
        
        # Clone repository temporarily to scan
        with tempfile.TemporaryDirectory() as tmpdir:
            clone_url = f"https://x-access-token:{github_token}@github.com/{repository}.git"
            
            click.echo(f"📥 Cloning repository...")
            result = subprocess.run(
                ["git", "clone", "--depth", "1", "--branch", branch, clone_url, tmpdir],
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode != 0:
                click.echo(f"❌ Failed to clone repository: {result.stderr}")
                sys.exit(1)
            
            # Scan for vulnerabilities
            click.echo(f"\n🔍 Scanning for vulnerabilities...")
            findings = collect_findings(
                path=tmpdir,
                severity=severity,
                enable_firmware=False,
                enable_urls=True,
                enable_dependencies=True,
                enable_workflows=True,
            )
            
            if not findings:
                click.echo("\n✅ No vulnerabilities found!")
                return
            
            click.echo(f"\n⚠️  Found {len(findings)} issue(s)")
            
            # Show findings summary
            severity_counts = {}
            for finding in findings:
                sev = finding.get("severity", "UNKNOWN")
                severity_counts[sev] = severity_counts.get(sev, 0) + 1
            
            for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
                if sev in severity_counts:
                    click.echo(f"  {sev}: {severity_counts[sev]}")
            
            if dry_run:
                click.echo("\n🔍 Dry run mode - no changes will be made")
                return
            
            # Confirm before fixing
            if not click.confirm("\n🔧 Apply fixes directly to GitHub?", default=True):
                click.echo("❌ Cancelled")
                return
            
            # Fix directly in GitHub
            click.echo(f"\n🔧 Applying fixes directly to GitHub...")
            result = fix_github_repository_direct(
                owner=owner,
                repo=repo,
                findings=findings,
                github_token=github_token,
                base_branch=branch,
                auto_commit=True
            )
            
            if result["success"]:
                click.echo(f"\n✅ Successfully fixed {len(result['fixed_files'])} file(s)")
                click.echo(f"   Branch: {result['branch']}")
                
                if result.get("pr_url"):
                    click.echo(f"   PR: {result['pr_url']}")
                
                if result.get("env_vars", 0) > 0:
                    click.echo(f"\n⚠️  {result['env_vars']} environment variable(s) extracted")
                    click.echo(f"   Add these to GitHub Secrets or your environment")
            else:
                click.echo(f"\n❌ Fix failed: {result.get('error', 'Unknown error')}")
                sys.exit(1)

    except GitHubAuthError as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        click.echo("\nRun 'sci github setup' to configure GitHub PAT")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)


@main.command()
@click.option("--dry-run", is_flag=True, help="Preview split without creating commits")
def split_commit(dry_run: bool) -> None:
    """Split large staged commit into logical chunks"""
    from sentinelci.core.commit_splitter import split_commits
    
    try:
        result = split_commits(".", dry_run)
        
        if not result["success"]:
            click.echo(f"❌ {result['error']}")
            sys.exit(1)
        
        if dry_run:
            click.echo(f"\n✅ Would create {result['groups']} commits")
            click.echo("Run without --dry-run to apply")
        else:
            click.echo(f"\n✅ Created {len(result['commits'])} commits")
            click.echo(f"📦 Split into {result['groups']} logical groups")
    
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
